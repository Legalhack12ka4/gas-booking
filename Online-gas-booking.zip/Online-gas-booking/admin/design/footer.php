<style>
.foot{
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   padding:10px;
   color: white;
   text-align: center;
   font-size:14px;
   background-color:#333333;
   font-weight:normal;
}
</style>
<footer class="site-footer foot">Copyright &copy;2018</footer>